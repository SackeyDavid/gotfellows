<!DOCTYPE html>
<html>
<head>
	<title>Vue Learing</title>
</head>
<body>
		<div id="app">
				<p>@{{ message }}</p>
				<input type="text" v-model="message">
		</div>

		<script src="js/vue.min.js"></script>
		<script src="js/script.js"></script>
</body>
</html>