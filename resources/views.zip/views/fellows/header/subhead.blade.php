<center>
<ul class="list-unstyled list-inline" style="color: #7f7f7f;">
<br><br><br><br>
		<li style="margin-right: 10%;"><b><a href="#allTab" data-toggle="tab" style="text-decoration: none;padding-left: 20px;padding-right: 20px; "><i class="fa fa-bookmark"></i> All 
		
		</a></b></li>
		<li style="margin-right: 10%;"><b><a href="#peopleTab" data-toggle="tab" style="text-decoration: none;"><i class="fa fa-male"></i> People </a></b></li>
		<li style="margin-right: 10%;"><b><a href="#placesTab" data-toggle="tab" style="text-decoration: none;"><i class="fa fa-map-marker"></i> Places</a></b></li>
		<li style="margin-right: 10%;"><b><a href="#eventsTab" data-toggle="tab" style="text-decoration: none;"><i class="fa fa-calendar"></i> Events</a></b></li>
		<!--<li class="dropdown">
		<a href="javascript:;" style="text-decoration: none;" class="dropdown-toggle" data-toggle="dropdown">
		More <b class="caret"></b><span class="glyphicon glyphicon-filter pull-right"></span></a>
    <ul class="dropdown-menu">
        <li><a href="#">Action</a></li>
        <li><a href="#">Another action</a></li>
        <li><a href="#">Something else here</a></li>
        <li><a href="#">Separated link</a></li>
        <li><a href="#">One more separated link</a></li>
    </ul>
                            

		</li>-->
</ul>
</center>

