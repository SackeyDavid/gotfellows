<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<h1>Hello , {{ $name }}! Welcome to GotFellows</h1>
</body>
</html>