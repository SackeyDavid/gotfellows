@include('fellows.content.fellows-all.home.fellows-people')

@section('people-content')


      @yield('fellows-people')
                
      
 
@endsection
