@include('fellows.content.fellows-all.home.fellows-place')

@section('places-content')


      @yield('fellows-place')
                
      
 
@endsection
