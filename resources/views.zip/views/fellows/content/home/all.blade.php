@include('fellows.content.fellows-all.home.fellows-all')


@section('all-content')


      @yield('fellows-all')
                
      
 
@endsection
