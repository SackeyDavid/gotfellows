@include('fellows.content.fellows-all.home.fellows-event')

@section('event-content')


      @yield('fellows-event')
                
      
 
@endsection
