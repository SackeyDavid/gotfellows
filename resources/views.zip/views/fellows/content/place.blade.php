@include('fellows.content.fellows-all.fellows-place')

@section('places-content')


      @yield('fellows-place')
                
      
 
@endsection
