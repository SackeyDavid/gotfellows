@include('fellows.content.fellows-all.fellows-event')

@section('event-content')


      @yield('fellows-event')
                
      
 
@endsection
