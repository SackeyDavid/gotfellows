@include('fellows.content.fellows-all.fellows-people')

@section('people-content')


      @yield('fellows-people')
                
      
 
@endsection
