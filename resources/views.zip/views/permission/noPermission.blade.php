<!DOCTYPE html>
<html>
<head>
	<title>Read Information</title>
</head>
<body>
	<b>Hi {{ Auth::user()->name }}, you have no right to use this method</b>
</body>
</html>