<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="Sharing- Knowing what people who share something with are doing">
    <meta name="author" content="Jabneel">
    <meta name="keyword" content="Sharing, People, Know, Picks, Fellows, Meineshule, Class, Career, Favourite">
    <link href="{{ URL::To('img/logo-big.png') }}" type="image/jpg" rel="shortcut icon"> 

	<title>Error</title>
</head>
<body>
		<h1>Error Page</h1>
</body>
</html>