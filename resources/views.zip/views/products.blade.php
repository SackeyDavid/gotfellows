@extends('layouts.dashboard-header')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            It's products
        </div>
    </div>
</div>
@endsection