<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Uploads extends Model
{
    // upload model
    protected $table = 'upload';
}
